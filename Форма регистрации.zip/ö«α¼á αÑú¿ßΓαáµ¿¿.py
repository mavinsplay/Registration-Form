from flask import Flask, render_template, redirect, request
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, IntegerField, BooleanField, EmailField
from wtforms.validators import DataRequired
from data.db_session import *


class LoginForm(FlaskForm):
    email = EmailField('Login / email')
    password = PasswordField('Password', validators=[DataRequired()])
    rep_password = PasswordField(
        'Repeat password', validators=[DataRequired()])
    surname = StringField('Surname', validators=[DataRequired()])
    name = StringField('Name', validators=[DataRequired()])
    age = IntegerField('Age', validators=[DataRequired()])
    position = StringField('Position', validators=[DataRequired()])
    speciality = StringField('Speciality', validators=[DataRequired()])
    address = StringField('Address', validators=[DataRequired()])
    remember_me = BooleanField('Remeber me')
    submit = SubmitField('Submit')


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        if form.password.data == form.rep_password.data:
            global_init("blogs.db")
            db_sess = create_session()
            user = User()
            user.surname = form.surname.data
            user.name = form.name.data
            user.age = form.age.data
            user.position = form.position.data
            user.speciality = form.speciality.data
            user.address = form.address.data
            user.email = form.email.data
            user.hashed_password = str(hash(form.password.data))
            user.modified_date = datetime.datetime.now()
            db_sess.add(user)
            db_sess.commit()
            return redirect('/success')
    else:
        print('\n\n\nPassword incorrect\n\n\n')
    return render_template('login.html', title='Аварийный доступ', form=form)


@app.route('/success')
def success():
    return render_template('sucess.html')


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
